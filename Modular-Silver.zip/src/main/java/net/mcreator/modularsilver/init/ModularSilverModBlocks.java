/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modularsilver.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.modularsilver.block.SilveroreBlock;
import net.mcreator.modularsilver.block.ModuletableBlock;
import net.mcreator.modularsilver.block.DeepslateSilverOreBlock;
import net.mcreator.modularsilver.ModularSilverMod;

import java.util.function.Function;

public class ModularSilverModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(ModularSilverMod.MODID);
	public static final DeferredBlock<Block> SILVER_ORE;
	public static final DeferredBlock<Block> DEEPSLATE_SILVER_ORE;
	public static final DeferredBlock<Block> MODULE_TABLE;
	static {
		SILVER_ORE = register("silver_ore", SilveroreBlock::new);
		DEEPSLATE_SILVER_ORE = register("deepslate_silver_ore", DeepslateSilverOreBlock::new);
		MODULE_TABLE = register("module_table", ModuletableBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}