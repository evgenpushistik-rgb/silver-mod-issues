/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modularsilver.init;

import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.modularsilver.client.gui.ModuletableGUIScreen;

@EventBusSubscriber(Dist.CLIENT)
public class ModularSilverModScreens {
	@SubscribeEvent
	public static void clientLoad(RegisterMenuScreensEvent event) {
		event.register(ModularSilverModMenus.MODULETABLE_GUI.get(), ModuletableGUIScreen::new);
	}

	public interface ScreenAccessor {
		void updateMenuState(int elementType, String name, Object elementState);
	}
}