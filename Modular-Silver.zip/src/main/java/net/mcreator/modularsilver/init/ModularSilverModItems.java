/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modularsilver.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.modularsilver.item.*;
import net.mcreator.modularsilver.ModularSilverMod;

import java.util.function.Function;

public class ModularSilverModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ModularSilverMod.MODID);
	public static final DeferredItem<Item> RAW_SILVER;
	public static final DeferredItem<Item> SILVER_ORE;
	public static final DeferredItem<Item> SILVER_INGOT;
	public static final DeferredItem<Item> DEEPSLATE_SILVER_ORE;
	public static final DeferredItem<Item> SILVER_HELMET;
	public static final DeferredItem<Item> SILVER_CHESTPLATE;
	public static final DeferredItem<Item> SILVER_LEGGINGS;
	public static final DeferredItem<Item> SILVER_BOOTS;
	public static final DeferredItem<Item> SILVER_PICKAXE;
	public static final DeferredItem<Item> SILVER_SWORD;
	public static final DeferredItem<Item> SILVER_AXE;
	public static final DeferredItem<Item> SILVER_SHOVEL;
	public static final DeferredItem<Item> SILVER_HOE;
	public static final DeferredItem<Item> MODULE_TABLE;
	public static final DeferredItem<Item> SCALE_MODULE;
	public static final DeferredItem<Item> EMPTY_MODULE;
	public static final DeferredItem<Item> SILVER_CHESTMODULE_SCALE_CHESTPLATE;
	static {
		RAW_SILVER = register("raw_silver", RawsilwerItem::new);
		SILVER_ORE = block(ModularSilverModBlocks.SILVER_ORE);
		SILVER_INGOT = register("silver_ingot", SilverIngotItem::new);
		DEEPSLATE_SILVER_ORE = block(ModularSilverModBlocks.DEEPSLATE_SILVER_ORE);
		SILVER_HELMET = register("silver_helmet", SilverItem.Helmet::new);
		SILVER_CHESTPLATE = register("silver_chestplate", SilverItem.Chestplate::new);
		SILVER_LEGGINGS = register("silver_leggings", SilverItem.Leggings::new);
		SILVER_BOOTS = register("silver_boots", SilverItem.Boots::new);
		SILVER_PICKAXE = register("silver_pickaxe", SilverpickaxeItem::new);
		SILVER_SWORD = register("silver_sword", SilverswordItem::new);
		SILVER_AXE = register("silver_axe", SilveraxeItem::new);
		SILVER_SHOVEL = register("silver_shovel", SilvershovelItem::new);
		SILVER_HOE = register("silver_hoe", SilverhoeItem::new);
		MODULE_TABLE = block(ModularSilverModBlocks.MODULE_TABLE, new Item.Properties().rarity(Rarity.RARE));
		SCALE_MODULE = register("scale_module", ModulescaleItem::new);
		EMPTY_MODULE = register("empty_module", EmptymoduleItem::new);
		SILVER_CHESTMODULE_SCALE_CHESTPLATE = register("silver_chestmodule_scale_chestplate", SilverChestmodulescaleItem.Chestplate::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}