/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modularsilver.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.modularsilver.ModularSilverMod;

@EventBusSubscriber
public class ModularSilverModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ModularSilverMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MODULESS = REGISTRY.register("moduless",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.modular_silver.moduless")).icon(() -> new ItemStack(ModularSilverModItems.EMPTY_MODULE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ModularSilverModItems.SCALE_MODULE.get());
				tabData.accept(ModularSilverModItems.EMPTY_MODULE.get());
			}).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MODULES = REGISTRY.register("modules",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.modular_silver.modules")).icon(() -> new ItemStack(ModularSilverModBlocks.MODULE_TABLE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(ModularSilverModItems.SILVER_CHESTMODULE_SCALE_CHESTPLATE.get());
			}).withTabsBefore(MODULESS.getId()).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(ModularSilverModItems.RAW_SILVER.get());
			tabData.accept(ModularSilverModItems.SILVER_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(ModularSilverModBlocks.SILVER_ORE.get().asItem());
			tabData.accept(ModularSilverModBlocks.DEEPSLATE_SILVER_ORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ModularSilverModItems.SILVER_HELMET.get());
			tabData.accept(ModularSilverModItems.SILVER_CHESTPLATE.get());
			tabData.accept(ModularSilverModItems.SILVER_LEGGINGS.get());
			tabData.accept(ModularSilverModItems.SILVER_BOOTS.get());
			tabData.accept(ModularSilverModItems.SILVER_SWORD.get());
			tabData.accept(ModularSilverModItems.SILVER_CHESTMODULE_SCALE_CHESTPLATE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ModularSilverModItems.SILVER_PICKAXE.get());
			tabData.accept(ModularSilverModItems.SILVER_AXE.get());
			tabData.accept(ModularSilverModItems.SILVER_SHOVEL.get());
			tabData.accept(ModularSilverModItems.SILVER_HOE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(ModularSilverModBlocks.MODULE_TABLE.get().asItem());
		}
	}
}