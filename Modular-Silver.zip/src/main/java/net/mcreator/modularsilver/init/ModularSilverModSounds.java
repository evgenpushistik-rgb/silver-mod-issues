/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.modularsilver.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.modularsilver.ModularSilverMod;

public class ModularSilverModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, ModularSilverMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> SCREWDRIVER = REGISTRY.register("screwdriver", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("modular_silver", "screwdriver")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SCALE = REGISTRY.register("scale", () -> SoundEvent.createVariableRangeEvent(Identifier.fromNamespaceAndPath("modular_silver", "scale")));
}