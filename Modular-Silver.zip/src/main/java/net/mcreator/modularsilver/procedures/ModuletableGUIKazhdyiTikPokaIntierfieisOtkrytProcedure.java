package net.mcreator.modularsilver.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.BlockPos;

import net.mcreator.modularsilver.init.ModularSilverModMenus;
import net.mcreator.modularsilver.init.ModularSilverModItems;

public class ModuletableGUIKazhdyiTikPokaIntierfieisOtkrytProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ModularSilverModMenus.MenuAccessor _menu0 ? _menu0.getSlots().get(1).getItem() : ItemStack.EMPTY).getItem() == Items.SLIME_BALL
				&& (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ModularSilverModMenus.MenuAccessor _menu2 ? _menu2.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == ModularSilverModItems.EMPTY_MODULE
						.get()) {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.bottle.fill")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("item.bottle.fill")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			if (entity instanceof Player _player && _player.containerMenu instanceof ModularSilverModMenus.MenuAccessor _menu) {
				ItemStack _setstack5 = new ItemStack(ModularSilverModItems.SCALE_MODULE.get()).copy();
				_setstack5.setCount(1);
				_menu.getSlots().get(0).set(_setstack5);
				_menu.getSlots().get(1).remove(1);
				_player.containerMenu.broadcastChanges();
			}
		}
		if ((entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ModularSilverModMenus.MenuAccessor _menu7 ? _menu7.getSlots().get(2).getItem() : ItemStack.EMPTY).getItem() == ModularSilverModItems.SILVER_CHESTPLATE.get()
				&& (entity instanceof Player _plrSlotItem && _plrSlotItem.containerMenu instanceof ModularSilverModMenus.MenuAccessor _menu9 ? _menu9.getSlots().get(0).getItem() : ItemStack.EMPTY).getItem() == ModularSilverModItems.SCALE_MODULE
						.get()) {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("modular_silver:screwdriver")), SoundSource.NEUTRAL, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(Identifier.parse("modular_silver:screwdriver")), SoundSource.NEUTRAL, 1, 1, false);
				}
			}
			if (entity instanceof Player _player && _player.containerMenu instanceof ModularSilverModMenus.MenuAccessor _menu) {
				ItemStack _setstack12 = new ItemStack(ModularSilverModItems.SILVER_CHESTMODULE_SCALE_CHESTPLATE.get()).copy();
				_setstack12.setCount(1);
				_menu.getSlots().get(3).set(_setstack12);
				_menu.getSlots().get(2).remove(1);
				_menu.getSlots().get(0).remove(1);
				_player.containerMenu.broadcastChanges();
			}
		}
	}
}