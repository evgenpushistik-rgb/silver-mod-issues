package net.mcreator.modularsilver.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class RawsilwerItem extends Item {
	public RawsilwerItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON));
	}
}