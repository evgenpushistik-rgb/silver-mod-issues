package net.mcreator.modularsilver.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class SilveraxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 100, 9f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("modular_silver:silver_axe_repair_items")));

	public SilveraxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 3f, -2f, properties);
	}
}