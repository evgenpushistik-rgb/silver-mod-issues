package net.mcreator.modularsilver.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class ModulescaleItem extends Item {
	public ModulescaleItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON).stacksTo(1));
	}
}