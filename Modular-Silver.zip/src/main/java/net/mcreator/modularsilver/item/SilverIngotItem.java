package net.mcreator.modularsilver.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SilverIngotItem extends Item {
	public SilverIngotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.UNCOMMON));
	}
}