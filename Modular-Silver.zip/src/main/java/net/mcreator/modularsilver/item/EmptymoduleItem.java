package net.mcreator.modularsilver.item;

import net.minecraft.world.item.Item;

public class EmptymoduleItem extends Item {
	public EmptymoduleItem(Item.Properties properties) {
		super(properties.stacksTo(16));
	}
}